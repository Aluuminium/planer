﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PlanerWatch
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public static Window2 Window;
       
        private Сотрудник _currentsotr = new Сотрудник();
        private Отдел _currentotd = new Отдел();
 
        public Window2(Сотрудник сотрудник)
        {
            InitializeComponent();
            UpdateData();
            Window = this;
            var allTypes = Class1.GetContext().Сотрудник.ToList();
            allTypes.Insert(0, new Сотрудник
            {
                Фамилия = "Все"
            });
            
            UpdateSotr();


        }
        private void UpdateSotr()
        {
            var _currentsotr = Class1.GetContext().Сотрудник.ToList();
            
            _currentsotr = _currentsotr.Where(p => p.Фамилия.ToLower().Contains(TBoxSearch.Text.ToLower())).ToList();
            var _currentotd = Class1.GetContext().Отдел.ToList();
            ComboType.ItemsSource = _currentotd;
            if (ComboType.SelectedIndex > -1)
                _currentsotr = _currentsotr.Where(p => p.Отдел == (ComboType.SelectedItem as Отдел)).ToList();
            dataGrid.ItemsSource = _currentsotr;
        }

        public void UpdateData()
        {
            Class1.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
            var join_massive = from sotr in Class1.GetContext().Сотрудник
                               select new
                               {
                                   ID_сотрудника = sotr.ID_сотрудника,
                                   Фамилия = sotr.Фамилия,
                                   Имя = sotr.Имя,
                                   Отчество = sotr.Отчество,
                                   Дата_рождения = sotr.Дата_рождения,
                                   Таб_номер = sotr.Таб_номер,
                                   Телефон = sotr.Телефон,
                                   Паспорт = sotr.Паспорт,
                                   ИНН = sotr.ИНН,
                                   Должность = sotr.Должность,
                                   Отдел = sotr.Отдел,
                                   Дата_найма = sotr.Дата_найма,
                                   Номер_договора = sotr.Номер_договора,
                        
                               };
            dataGrid.ItemsSource = join_massive.ToList();

        }

        private void Drag(object sender, RoutedEventArgs e)
        {
            if (Mouse.LeftButton == MouseButtonState.Pressed)
            {
                Window2.Window.DragMove();
            }
        }
        private void BtnRedactor_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            Window3 window3 = new Window3(Class1.GetContext().Сотрудник.Where(p=> p.ID_сотрудника ==(int)button.Tag).First());
            window3.Owner = this;
            window3.Show();
        }

        private void btn_exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void BtnNazad_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Btn_ydal_sotr_Click(object sender, RoutedEventArgs e)
        {

            if (dataGrid.SelectedItem != null)
            {
                MessageBoxResult messageBoxResult = MessageBox.Show("Вы действительно хотите удалить запись?", "Удаление записи", MessageBoxButton.YesNo);
                if (messageBoxResult == MessageBoxResult.Yes)
                {
                    int id = (int)TypeDescriptor.GetProperties(dataGrid.SelectedItem)[0].GetValue(dataGrid.SelectedItem);
                    Сотрудник сотрудник = Class1.GetContext().Сотрудник.Where(p => p.ID_сотрудника == id).FirstOrDefault();
                    Class1.GetContext().Сотрудник.Remove(сотрудник);
                    Class1.GetContext().SaveChanges();
                    Class1.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                    dataGrid.ItemsSource = Class1.GetContext().Сотрудник.ToList();
                }
            }
        }

        private void TBoxSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateSotr();
        }

        private void ComboType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateSotr();
        }
         //if (!String.IsNullOrEmpty(ComboType.Text)) //фильтрация
          //  {
             //   Отдел ch = ComboType.SelectedItem as Отдел;
       // _currentotd = _currentotd.Where(p => p.ID_отдела == ch.Название);
         //   }
}
}
