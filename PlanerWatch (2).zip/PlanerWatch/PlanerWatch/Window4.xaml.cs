﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PlanerWatch
{
    /// <summary>
    /// Логика взаимодействия для Window4.xaml
    /// </summary>
    public partial class Window4 : Window
    {
        public static Window4 Window;
        private Сотрудник _currentsotr = new Сотрудник();
        public Window4(Сотрудник сотрудник)
        {
            InitializeComponent();
            Window = this;
            UpdateData();
        }
        public void UpdateData()
        {
            Class1.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
            var join_massive = from sotr in Class1.GetContext().АрхивСотрудник
                               select new
                               {
                                   ID_сотрудника = sotr.ID_сотрудника,
                                   Фамилия = sotr.Фамилия,
                                   Имя = sotr.Имя,
                                   Отчество = sotr.Отчество,
                                   Дата_рождения = sotr.Дата_рождения,
                                   Таб_номер = sotr.Таб_номер,
                                   Телефон = sotr.Телефон,
                                   Паспорт = sotr.Паспорт,
                                   ИНН = sotr.ИНН,
                                   Должность = sotr.Должность,
                                   Отдел = sotr.Отдел,
                                   Дата_найма = sotr.Дата_найма,
                                   Номер_договора = sotr.Номер_договора,

                               };
            dataGrid.ItemsSource = join_massive.ToList();

        }

        private void Drag(object sender, RoutedEventArgs e)
        {
            if (Mouse.LeftButton == MouseButtonState.Pressed)
            {
                Window1.Window.DragMove();
            }
        }



        private void btn_exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void BtnNazad_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
