﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PlanerWatch
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public static Window1 Window;
        private Сотрудник Сотрудник;
        private Сотрудник _currentsotr = new Сотрудник();
        public Window1(Сотрудник Сотрудник)
        {
            InitializeComponent();
            Window = this;
            this.Сотрудник = Сотрудник;
            family_label.Content = Сотрудник.Фамилия;
            name_label.Content = Сотрудник.Имя;
            var _currentsotr = Class1.GetContext().Сотрудник.ToList();
            LViewSotr.ItemsSource = _currentsotr;
            UpdateData();
        }

        public void UpdateData()
        {
            Class1.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
            var join_massive = from sotr in Class1.GetContext().Сотрудник
                               select new
                               {
                                   ID_сотрудника = sotr.ID_сотрудника,
                                   Фамилия = sotr.Фамилия,
                                   Имя = sotr.Имя,
                                   Отчество = sotr.Отчество,
                                   Дата_рождения = sotr.Дата_рождения,
                                   Таб_номер = sotr.Таб_номер,
                                   Телефон = sotr.Телефон,
                                   Паспорт = sotr.Паспорт,
                                   ИНН = sotr.ИНН,
                                   Должность = sotr.Должность,
                                   Отдел = sotr.Отдел,
                                   Дата_найма = sotr.Дата_найма,
                                   Номер_договора = sotr.Номер_договора,

                               };
            

        }
        private void Drag(object sender, RoutedEventArgs e)
        {
            if (Mouse.LeftButton == MouseButtonState.Pressed)
            {
                Window1.Window.DragMove();
            }
        }
        private void exit_button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btn_exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btn_arhiv_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            Window4 window4 = new Window4(Сотрудник);
            window4.Owner = this;
            window4.Show();
        }

        private void BtnRedactor_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            Window2 window2 = new Window2(Сотрудник);
            window2.Owner = this;
            window2.Show();
        }

        private void btn_dobav_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            Window5 window5 = new Window5();
            window5.Owner = this;
            window5.Show();
        }

        private void btn_diagr_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            Window6 window6 = new Window6();
            window6.Owner = this;
            window6.Show();
        }

        private void btn_otchet_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
