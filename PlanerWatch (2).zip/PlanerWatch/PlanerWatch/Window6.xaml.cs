﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Word = Microsoft.Office.Interop.Word;


namespace PlanerWatch
{
    /// <summary>
    /// Логика взаимодействия для Window6.xaml
    /// </summary>
    public partial class Window6 : Window
    {
        public static Window6 Window;
        public Window6()
        {
            InitializeComponent();
            Window = this;
            chart.Titles.Add("Данные о сотрудниках");
            chart.ChartAreas.Add(new System.Windows.Forms.DataVisualization.Charting.ChartArea("Default"));
            chart.Series.Add(new System.Windows.Forms.DataVisualization.Charting.Series("Количество сотрудников за год")
            {
                ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Column
            });
            int minYear = Class1.GetContext().Сотрудник.Min(p => p.Дата_найма).Year;
            int maxYear = Class1.GetContext().Сотрудник.Max(p => p.Дата_найма).Year;

            List<int> year_sotr = new List<int>();
            List<int> count_sotr = new List<int>();
            for (int i = minYear; i <= maxYear; i++)
            {
                year_sotr.Add(i);
                count_sotr.Add(Class1.GetContext().Сотрудник.Count(p => p.Дата_найма.Year == i));
            }
            chart.Series["Количество сотрудников за год"].Points.DataBindXY(year_sotr, count_sotr);
        }

        private void Drag(object sender, RoutedEventArgs e)
        {
            if (Mouse.LeftButton == MouseButtonState.Pressed)
            {
                Window6.Window.DragMove();
            }
        }
        private void btn_exit_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Application.Current.Shutdown();
        }

        private void BtnNazad_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        object oMissing = System.Reflection.Missing.Value;

        private void Btnotchet_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Word document(*.docx) |*.docx";
            if (saveFileDialog.ShowDialog() == true)
            {
                object oMissing = System.Reflection.Missing.Value;
                Word.Application word_app = new Word.Application();
                word_app.Visible = true;
                Word.Document doc = word_app.Documents.Add(ref oMissing, ref oMissing, ref oMissing, ref oMissing);

                Word.Paragraph par_zag = doc.Content.Paragraphs.Add(ref oMissing);
                par_zag.Range.Text = "Отчет по принятию сотрудников";
                par_zag.Range.Font.Color = Word.WdColor.wdColorBlack;
                par_zag.Range.Font.Bold = 1;
                par_zag.Range.Font.Size = 16f;
                par_zag.Range.Font.Name = "Times New Roman";
                par_zag.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                par_zag.Range.InsertParagraphAfter();

                Word.Paragraph table_par = doc.Content.Paragraphs.Add(ref oMissing);
                Word.Table table = doc.Content.Tables.Add(table_par.Range, Class1.GetContext().Сотрудник.Count() + 1, 4, ref oMissing, ref oMissing);
                table.Range.Font.Size = 12f;
                table.Range.Font.Bold = 0;
                table.Rows[1].Range.Font.Bold = 1;
                table.Cell(1, 1).Range.Text = "Фамилия сотрудника";
                table.Cell(1, 2).Range.Text = "Имя сотрудника";
                table.Cell(1, 3).Range.Text = "Отчество сотрудника";
                table.Cell(1, 4).Range.Text = "Дата найма сотрудника";
                table.Borders.InsideLineStyle = Word.WdLineStyle.wdLineStyleSingle;
                table.Borders.OutsideLineStyle = Word.WdLineStyle.wdLineStyleSingle;

                for (int i = 0; i < Class1.GetContext().Сотрудник.Count(); i++)
                {
                    for (int j = 1; j <= table.Columns.Count; j++)
                    {
                        switch(j)
                        {
                            case 1:
                                table.Cell(i + 2, j).Range.Text = Class1.GetContext().Сотрудник.ToList()[i].Фамилия;
                                break;
                            case 2:
                                table.Cell(i + 2, j).Range.Text = Class1.GetContext().Сотрудник.ToList()[i].Имя;
                                break;
                            case 3:
                                table.Cell(i + 2, j).Range.Text = Class1.GetContext().Сотрудник.ToList()[i].Отчество;
                                break;
                           

                        }
                    }

                }
                doc.SaveAs2(saveFileDialog.FileName, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing);
            }
        }
    }
}
