﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PlanerWatch
{
    /// <summary>
    /// Логика взаимодействия для Window5.xaml
    /// </summary>
    public partial class Window5 : Window
    {
        public static Window5 Window;
        public Window5()
        {
            InitializeComponent();
            Window = this;

        }
        private void Drag(object sender, RoutedEventArgs e)
        {
            if (Mouse.LeftButton == MouseButtonState.Pressed)
            {
                Window5.Window.DragMove();
            }
        }

        private void btn_exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void BtnNazad_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            if (data_rozhd_datePicker.SelectedDate == null)
                errors.AppendLine("Укажите дату рождения");
            if (data_naima_datePicker.SelectedDate == null)
                errors.AppendLine("Укажите дату найма");
            if (id_textBox1.SelectedText == null)
                errors.AppendLine("Укажите ID сотрудника");
            if (surname_textBox1.SelectedText == null)
                errors.AppendLine("Укажите фамилию сотрудника");
            if (name_textBox1.SelectedText == null)
                errors.AppendLine("Укажите имя сотрудника");
            if (otch_textBox1.SelectedText == null)
                errors.AppendLine("Укажите отчество сотрудника");
            if (tab_nom_textBox1.SelectedText == null)
                errors.AppendLine("Укажите табельный номер сотрудника");
            if (pasport_textBox1.SelectedText == null)
                errors.AppendLine("Укажите паспортные данные сотрудника");
            if (inn_textBox1.SelectedText == null)
                errors.AppendLine("Укажите ИНН сотрудника");
            if (dolzh_textBox1.SelectedText == null)
                errors.AppendLine("Укажите ID должности сотрудника");
            if (otd_textBox1.SelectedText == null)
                errors.AppendLine("Укажите ID отдела сотрудника");
            if (telephone_textBox1.SelectedText == null)
                errors.AppendLine("Укажите телефон сотрудника");
            if (login_textBox1.SelectedText == null)
                errors.AppendLine("Укажите логин сотрудника");
            if (parol_textBox1.SelectedText == null)
                errors.AppendLine("Укажите пароль сотрудника");
            if (nom_dog_textBox1.SelectedText == null)
                errors.AppendLine("Укажите номер договора с сотрудником");
            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }
            Class1.GetContext().Сотрудник.Add(new Сотрудник()
            {
                ID_сотрудника = Int32.Parse(id_textBox1.Text),
                Фамилия = surname_textBox1.Text,
                Имя = name_textBox1.Text,
                Отчество = otch_textBox1.Text,
                Таб_номер = Int32.Parse(tab_nom_textBox1.Text),
                Паспорт = pasport_textBox1.Text,
                ИНН = Int32.Parse(inn_textBox1.Text),
                ID_должности = Int32.Parse(dolzh_textBox1.Text),
                ID_отдела = Int32.Parse(otd_textBox1.Text),
                Телефон = telephone_textBox1.Text,
                Дата_рождения = data_rozhd_datePicker.SelectedDate.Value,
                Дата_найма = data_naima_datePicker.SelectedDate.Value,
                Логин = login_textBox1.Text,
                Пароль = parol_textBox1.Text,
                Номер_договора = nom_dog_textBox1.Text

            });
            Class1.GetContext().SaveChanges();
            ((Window1)this.Owner).UpdateData();
            MessageBox.Show("Данные успешно добавлены!");
            this.Close();

        }
    }
}
